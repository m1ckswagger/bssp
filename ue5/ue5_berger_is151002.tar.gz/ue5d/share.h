#ifndef SHARE_H_
#define SHARE_H_

#define MAX_MSG_LEN 256
#define MAX_MSG_COUNT 10

#define QUEUE_NAME "/is151002_mq1"
#define PIPE_NAME "is151002_pipe"

#endif
